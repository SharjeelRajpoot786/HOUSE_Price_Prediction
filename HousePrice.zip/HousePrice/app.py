from flask import Flask, request, render_template
import joblib

app = Flask(__name__)

# Load model and columns
model = joblib.load("model.pkl")
model_columns = joblib.load("model_columns.pkl")

@app.route('/')
def home():
    print("Rendering home page...")
    return render_template('index.html', model_columns=model_columns)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        input_data = [float(request.form[col]) for col in model_columns]
        prediction = model.predict([input_data])[0]
        return render_template('index.html',
                               prediction_text=f"Predicted House Price: ${prediction:,.2f}",
                               model_columns=model_columns)
    except Exception as e:
        return f"Error: {str(e)}"

if __name__ == '__main__':
    print("Starting Flask app...")
    app.run(debug=True)
